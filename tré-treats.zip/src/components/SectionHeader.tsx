/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  center?: boolean;
}

export default function SectionHeader({ title, subtitle, center = false }: SectionHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
      className={`mb-12 ${center ? "text-center mx-auto" : ""} max-w-2xl`}
    >
      {subtitle && (
        <span className="text-secondary font-semibold uppercase tracking-widest text-sm mb-4 block">
          {subtitle}
        </span>
      )}
      <h2 className="text-4xl md:text-5xl font-serif text-primary leading-tight">
        {title}
      </h2>
      <div className={`h-1.5 w-20 bg-secondary rounded-full mt-6 ${center ? "mx-auto" : ""}`} />
    </motion.div>
  );
}
