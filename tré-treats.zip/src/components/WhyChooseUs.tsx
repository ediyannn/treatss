/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import SectionHeader from "./SectionHeader";
import { BadgeDollarSign, ShieldCheck, Smile, GraduationCap, Zap } from "lucide-react";

export default function WhyChooseUs() {
  const features = [
    {
      icon: BadgeDollarSign,
      title: "Affordable Prices",
      desc: "Premium taste shouldn't break the bank. We offer the best value for students."
    },
    {
      icon: ShieldCheck,
      title: "Fresh & Safe",
      desc: "We use only high-quality, safe ingredients in every batch we prepare."
    },
    {
      icon: Smile,
      title: "Customer First",
      desc: "Our goal is your satisfaction. We build loyalty through excellent service."
    },
    {
      icon: GraduationCap,
      title: "Student Friendly",
      desc: "The perfect quick comfort snack for school breaks and study sessions."
    },
    {
      icon: Zap,
      title: "Handcrafted",
      desc: "Every treat is made with love and creative attention to detail."
    }
  ];

  return (
    <section className="section-padding bg-white relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-accent/20 rounded-full blur-3xl -z-0 translate-x-1/2 -translate-y-1/2" />
      
      <SectionHeader 
        center 
        subtitle="The TRÉ Advantage" 
        title="Why Choose Our Treats?" 
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative z-10">
        {features.map((f, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="p-10 rounded-[40px] bg-brand-cream hover:bg-white border border-transparent hover:border-secondary/20 hover:shadow-premium transition-all duration-500 group"
          >
            <div className="w-16 h-16 rounded-2xl bg-white flex items-center justify-center text-primary mb-6 shadow-sm group-hover:bg-primary group-hover:text-white transition-all duration-500">
              <f.icon size={32} />
            </div>
            <h3 className="text-2xl font-bold text-primary mb-4">{f.title}</h3>
            <p className="text-gray-500 leading-relaxed">
              {f.desc}
            </p>
          </motion.div>
        ))}
        
        {/* Decorative Item */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="p-10 rounded-[40px] bg-primary flex flex-col justify-center items-center text-center text-white"
        >
          <div className="mb-6">
            <img 
              src="treata.jpg" 
              alt="Crispy Treat" 
              className="w-32 h-32 object-cover rounded-2xl shadow-xl rotate-12"
              onError={(e) => {
                 (e.target as HTMLImageElement).src = "https://placehold.co/200x200?text=Crunch";
              }}
            />
          </div>
          <h3 className="text-2xl font-serif mb-2 text-secondary">Ready to try?</h3>
          <p className="text-white/70 mb-6 font-medium">Experience the crunch today.</p>
          <button className="px-6 py-2 bg-white text-primary rounded-full font-bold hover:bg-secondary transition-colors">
            Shop Now
          </button>
        </motion.div>
      </div>
    </section>
  );
}
