/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import SectionHeader from "./SectionHeader";

export default function Gallery() {
  const images = [
    { src: "treata.jpg", size: "col-span-2 row-span-2" },
    { src: "https://images.unsplash.com/photo-1559620192-032c4bc4674e?auto=format&fit=crop&q=80&w=400", size: "col-span-1 row-span-1" },
    { src: "https://images.unsplash.com/photo-1559622214-f8a9850965bb?auto=format&fit=crop&q=80&w=400", size: "col-span-1 row-span-1" },
    { src: "https://images.unsplash.com/photo-1621236378699-8597fac6bb4d?auto=format&fit=crop&q=80&w=600", size: "col-span-1 row-span-2" },
    { src: "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&q=80&w=400", size: "col-span-1 row-span-1" },
  ];

  return (
    <section id="gallery" className="section-padding overflow-hidden">
      <SectionHeader center subtitle="Visual Treats" title="Our Aesthetic Gallery" />
      
      <div className="grid grid-cols-2 md:grid-cols-4 grid-rows-3 gap-4 h-[600px] md:h-[800px]">
        {images.map((img, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.5 }}
            className={`${img.size} rounded-[30px] overflow-hidden group relative shadow-lg`}
          >
            <img
              src={img.src}
              alt={`Gallery ${i}`}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              onError={(e) => {
                 (e.target as HTMLImageElement).src = `https://placehold.co/400x400?text=Treat+${i+1}`;
              }}
            />
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </motion.div>
        ))}
      </div>
      
      <motion.div 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="mt-12 text-center"
      >
        <p className="text-gray-500 font-medium italic">Tag us on Instagram @TreTreatsDagupan to be featured!</p>
      </motion.div>
    </section>
  );
}
