/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { ChevronRight, Play } from "lucide-react";
import { CONTENT, BRAND_NAME } from "../constants";

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-secondary/10 -z-10 rounded-l-[100px] hidden lg:block" />
      <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-accent/30 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-6 w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex flex-col gap-6"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-secondary/20 text-primary text-sm font-semibold w-fit">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-secondary"></span>
            </span>
            Premium Desserts
          </div>

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif text-primary leading-[1.1]">
            Sweetness <br />
            <span className="text-secondary italic">Crafted</span> in <br />
            Every Bite
          </h1>

          <p className="text-lg md:text-xl text-gray-600 max-w-lg leading-relaxed">
            {CONTENT.hero.tagline}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mt-4">
            <button className="btn-primary group">
              Order Now
              <ChevronRight className="inline-block ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </button>
            <button className="btn-outline group">
              View Menu
            </button>
          </div>
          
          <div className="mt-8 flex items-center gap-6 text-sm font-medium text-gray-500">
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-accent flex items-center justify-center text-xs">
                  {8 + i}k+
                </div>
              ))}
            </div>
            <span>Trusted by 5000+ Sweet Lovers</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <div className="relative z-10 w-full aspect-square max-w-[500px] mx-auto group">
             {/* Logo as main branding element in Hero */}
            <div className="absolute inset-0 bg-white rounded-[60px] shadow-2xl overflow-hidden p-8 flex items-center justify-center">
              <img
                src="treata.jpg"
                alt="Tre Treats Logo"
                className="w-full h-full object-contain hover:scale-105 transition-transform duration-700"
                onError={(e) => {
                   (e.target as HTMLImageElement).src = "https://placehold.co/400x400?text=Logo";
                }}
              />
            </div>
            
            {/* Decal images or floating elements */}
            <motion.div 
              animate={{ y: [0, -20, 0] }} 
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className="absolute -top-10 -right-10 w-32 h-32 bg-secondary rounded-3xl -z-10 rotate-12"
            />
            <motion.div 
              animate={{ y: [0, 20, 0] }} 
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut", delay: 1 }}
              className="absolute -bottom-10 -left-10 w-40 h-40 bg-accent rounded-full -z-10"
            />
          </div>
          
          {/* Floating Product Image Reveal */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="absolute bottom-4 right-4 bg-white p-3 rounded-2xl shadow-xl flex items-center gap-3 z-20"
          >
            <img 
              src="/input_file_1.png" 
              alt="Rice Treat" 
              className="w-12 h-12 rounded-lg object-cover" 
              onError={(e) => {
                 (e.target as HTMLImageElement).src = "https://placehold.co/100x100?text=Treat";
              }}
            />
            <div>
              <p className="text-xs font-bold text-primary">Best Seller</p>
              <p className="text-[10px] text-gray-500">Classic Rice Treat</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
