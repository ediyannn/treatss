/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import SectionHeader from "./SectionHeader";
import { CONTENT } from "../constants";
import { Plus } from "lucide-react";

export default function Products() {
  return (
    <section id="products" className="section-padding bg-[#FFF5EE]">
      <SectionHeader 
        center 
        subtitle="Our Collection" 
        title="Featured Treats" 
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {CONTENT.products.map((product, i) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="card-premium h-full flex flex-col group"
          >
            <div className="relative aspect-[4/5] overflow-hidden">
              <img
                src={i === 0 ? "/input_file_1.png" : "https://images.unsplash.com/photo-1548598146-f82a0d9bed71?auto=format&fit=crop&q=80&w=400"}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                onError={(e) => {
                   (e.target as HTMLImageElement).src = `https://placehold.co/400x500?text=${product.name}`;
                }}
              />
              <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-sm font-bold text-primary shadow-sm">
                {product.price}
              </div>
              <button className="absolute bottom-4 right-4 bg-primary text-white p-3 rounded-full shadow-lg opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                <Plus size={20} />
              </button>
            </div>
            
            <div className="p-6 flex flex-col flex-grow">
              <h3 className="text-xl font-bold text-primary mb-2 group-hover:text-secondary transition-colors">
                {product.name}
              </h3>
              <p className="text-gray-500 text-sm leading-relaxed mb-4 flex-grow">
                {product.description}
              </p>
              <div className="flex items-center justify-between mt-auto">
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <div key={s} className="w-2 h-2 rounded-full bg-secondary" />
                  ))}
                </div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-secondary">
                  Local Favorite
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-20 relative rounded-[50px] overflow-hidden bg-primary p-12 lg:p-20 flex flex-col lg:flex-row items-center gap-12">
        <div className="absolute top-0 right-0 w-full h-full opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent pointer-none" />
        
        <div className="relative z-10 flex-1 text-white">
          <h2 className="text-4xl lg:text-5xl font-serif mb-6 leading-tight">
            Craving something <br /> <span className="text-secondary italic">Special?</span>
          </h2>
          <p className="text-accent/80 text-lg mb-8 max-w-lg">
            We offer customized bulk orders for parties, school events, and special celebrations. Make your occasions sweeter with TRÉ TREATS.
          </p>
          <div className="flex flex-wrap gap-4">
            <button className="px-8 py-3 bg-white text-primary rounded-full font-bold hover:bg-accent transition-colors">
              Request Quote
            </button>
            <button className="px-8 py-3 bg-transparent border-2 border-white text-white rounded-full font-bold hover:bg-white/10 transition-colors">
              Our Full Menu
            </button>
          </div>
        </div>

        <div className="relative z-10 flex-1 w-full max-w-sm">
           <img 
            src="tre.jpg" 
            alt="Signature Pack" 
            className="w-full h-auto rounded-3xl shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-500" 
            onError={(e) => {
               (e.target as HTMLImageElement).src = "https://placehold.co/400x400?text=Premium+Pack";
            }}
          />
          <div className="absolute -top-6 -left-6 bg-secondary text-primary w-20 h-20 rounded-full flex items-center justify-center font-bold text-center text-sm leading-tight p-2 shadow-xl border-4 border-primary">
            BEST VALUE
          </div>
        </div>
      </div>
    </section>
  );
}
