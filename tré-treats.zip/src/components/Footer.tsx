/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BRAND_NAME, CONTENT } from "../constants";
import { Coffee, Heart, ArrowUp } from "lucide-react";

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-primary text-white pt-20 pb-10 px-6 overflow-hidden relative">
      <div className="absolute top-0 right-0 w-64 h-64 bg-secondary/10 rounded-full blur-3xl -z-0" />
      
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 relative z-10">
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-2">
            <img 
              src="treata.jpg" 
              alt={BRAND_NAME} 
              className="h-10 w-10 brightness-0 invert object-contain"
              onError={(e) => {
                 (e.target as HTMLImageElement).src = "https://placehold.co/100x100?text=Logo";
              }}
            />
            <span className="text-2xl font-serif font-bold tracking-tight">
              {BRAND_NAME}
            </span>
          </div>
          <p className="text-accent/60 text-sm leading-relaxed">
            Crafting sweet moments with artisanal rice treats. Born from passion, shared with love.
          </p>
          <div className="flex items-center gap-2 text-xs font-bold text-secondary">
            <Coffee size={14} /> Established 2026
          </div>
        </div>

        <div>
          <h4 className="font-bold text-lg mb-6">Explore</h4>
          <ul className="space-y-4 text-sm text-accent/60">
            <li><a href="#home" className="hover:text-secondary transition-colors">Home</a></li>
            <li><a href="#about" className="hover:text-secondary transition-colors">Our Story</a></li>
            <li><a href="#products" className="hover:text-secondary transition-colors">Menu</a></li>
            <li><a href="#gallery" className="hover:text-secondary transition-colors">Gallery</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-lg mb-6">Business</h4>
          <ul className="space-y-4 text-sm text-accent/60">
            <li>Wholesale</li>
            <li>Partnerships</li>
            <li>Careers</li>
            <li>Terms of Service</li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-lg mb-6">Join Our Newsletter</h4>
          <p className="text-sm text-accent/60 mb-6 leading-relaxed">
            Get sweet updates and special discounts delivered to your inbox.
          </p>
          <div className="flex gap-2">
            <input 
              type="email" 
              placeholder="Your email" 
              className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:ring-1 focus:ring-secondary w-full"
            />
            <button className="bg-secondary text-primary px-4 py-2 rounded-full font-bold text-sm hover:bg-white transition-colors">
              Join
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-20 pt-10 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-6">
        <p className="text-xs text-accent/40">
          © 2026 {BRAND_NAME}. All rights reserved.
        </p>
        
        <div className="flex items-center gap-2 text-xs text-accent/40">
          Made with <Heart size={12} className="text-secondary fill-secondary" /> in the Philippines
        </div>

        <button 
          onClick={scrollToTop}
          className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-white/5 transition-all group"
        >
          <ArrowUp size={16} className="group-hover:-translate-y-1 transition-transform" />
        </button>
      </div>
    </footer>
  );
}
