/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import SectionHeader from "./SectionHeader";
import { CONTENT } from "../constants";
import { Heart, Target, Sparkles } from "lucide-react";

export default function About() {
  const stats = [
    { icon: Heart, label: "Made with Love", text: "Handcrafted goodness" },
    { icon: Target, label: "Our Mission", text: "Sweetness to every Filipino" },
    { icon: Sparkles, label: "Quality First", text: "Fresh and safe ingredients" },
  ];

  return (
    <section id="about" className="section-padding overflow-hidden">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative group"
        >
          {/* Creative image container */}
          <div className="rounded-[40px] overflow-hidden aspect-[4/5] relative">
            <img 
              src="teats.jpg" 
              alt="Artisanal Desserts" 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              onError={(e) => {
                 (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1548598146-f82a0d9bed71?auto=format&fit=crop&q=80&w=600";
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-10">
               <p className="text-white text-lg font-medium italic">"Quality you can taste, love you can feel."</p>
            </div>
          </div>
          
          {/* Decorative floating card */}
          <div className="absolute -bottom-10 -right-10 bg-accent p-8 rounded-3xl shadow-2xl max-w-[200px] hidden md:block">
            <h3 className="text-primary font-bold text-3xl mb-1">2026</h3>
            <p className="text-gray-600 text-sm">Established with a vision for sweetness.</p>
          </div>
        </motion.div>

        <div>
          <SectionHeader 
            subtitle="The Story of TRÉ" 
            title={CONTENT.about.title} 
          />
          
          <div className="space-y-6 text-gray-600 leading-relaxed text-lg">
            <p>{CONTENT.about.description}</p>
            <div className="bg-secondary/10 p-6 rounded-3xl border-l-4 border-secondary">
              <p className="italic text-primary font-medium">
                "Our name symbolizes unity. Just as three elements come together, our passion, creativity, and commitment to quality form the heart of every treat."
              </p>
            </div>
            <p>
              Located at <strong>{CONTENT.contact.location}</strong>, we are proud to be Dagupan's favorite spot for a quick, crispy reward.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12">
            {stats.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex flex-col gap-3"
              >
                <div className="w-12 h-12 rounded-2xl bg-secondary/10 flex items-center justify-center text-secondary">
                  <item.icon size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-primary">{item.label}</h4>
                  <p className="text-xs text-gray-500">{item.text}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <button className="btn-primary mt-12 px-10">Learn Our Mission</button>
        </div>
      </div>
    </section>
  );
}
