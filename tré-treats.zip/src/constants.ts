/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const BRAND_NAME = "TRÉ TREATS";

export const COLORS = {
  primary: "#4A2C2A", // Dark Brown - chocolate, richness
  secondary: "#D2B48C", // Tan/Light Brown - crispy texture
  accent: "#F5F5DC", // Beige - warmth and comfort
  white: "#FFFFFF",
  text: "#2D1B19",
  background: "#FFFAF5", // Creamy background
};

export const CONTENT = {
  hero: {
    title: "Sweet Moments in Every Bite",
    tagline: "Experience the perfect blend of crispiness and rich chocolate in our artisanal treats.",
  },
  about: {
    title: "Our Story",
    description: "Tré Treats was born from a common passion for cooking and a creative approach to using simple materials. The word 'Tré' is inspired by the Italian word 'tre' (three), symbolizing the unity and collaboration that form our foundation. We believe that small treats provide comfort and refreshing moments in busy lives.",
    vision: "To be a successful and trusted dessert business that brings joy and satisfaction to customers through delicious, high quality and creative treats.",
    mission: "To bring sweetness and smiles to every Filipino by offering crave worthy treats made with love, care, and utmost value.",
  },
  products: [
    {
      id: 1,
      name: "Classic Rice Treats",
      price: "₱25.00",
      description: "Our signature crispy rice squares, light and perfectly sweet.",
    },
    {
      id: 2,
      name: "Chocolate Drizzle Bars",
      price: "₱35.00",
      description: "Crispy treats topped with a rich, dark chocolate drizzle.",
    },
    {
      id: 3,
      name: "Caramel Crunch Squares",
      price: "₱40.00",
      description: "A gooey caramel layer over our classic crispy base.",
    },
    {
      id: 4,
      name: "Premium Crispy Bites",
      price: "₱50.00",
      description: "Double chocolate dip with toasted nuts for a premium experience.",
    },
  ],
  testimonials: [
    {
      name: "Maria Santos",
      role: "Student",
      comment: "The perfect snack for long study sessions! Not too sweet, just right.",
    },
    {
      name: "Juan Dela Cruz",
      role: "Regular Customer",
      comment: "You can taste the quality and care in every bite. Truly premium treats.",
    },
    {
      name: "Liza Soberano",
      role: "Food Blogger",
      comment: "TRE TREATS are my new favorite. The texture is incredible!",
    }
  ],
  contact: {
    email: "tretreats@gmail.com",
    phone: "+63 912 345 6789",
    location: "Zamora Street, Dagupan City",
    socials: {
      facebook: "#",
      instagram: "#",
      tiktok: "#"
    }
  }
};

// Image references
export const ASSETS = {
  logo: "https://raw.githubusercontent.com/antigravity-app/assets/main/tre-treats/logo.png", // Fallback placeholder
  product: "https://raw.githubusercontent.com/antigravity-app/assets/main/tre-treats/product.png", // Fallback placeholder
  // Note: I will use the local paths if they exist, but these are placeholders for now.
  // Actually, I'll use the filenames input_file_0.png and input_file_1.png in the components directly
  // if I want to be safe.
};
